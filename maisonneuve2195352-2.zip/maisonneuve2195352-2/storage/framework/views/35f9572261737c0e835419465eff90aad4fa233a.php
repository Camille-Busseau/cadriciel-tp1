
<?php $__env->startSection('title', 'Collège de Maisonneuve'); ?>
<?php $__env->startSection('titleH1', 'Étudiantes & Étudiants'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mt-3">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Numéro d'identification</th>
                    <th>Nom</th>
                    <th>Courriel</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student->id); ?></td>
                    <td>
                        <a href="<?php echo e(route('maisonneuve.show', $student->id)); ?>"><?php echo e($student->name); ?></a>
                    </td>
                    <td><?php echo e($student->email); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($students); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cadriciel23\maisonneuve2195352-2\resources\views/maisonneuve/index.blade.php ENDPATH**/ ?>