
<?php $__env->startSection('title', 'Créer un nouveau profil'); ?>
<?php $__env->startSection('titleH1', 'Créer un nouveau profil'); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-4 justify-content-center">
    <div class="col-6">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-header">
                    Créer un profil d'un.e nouvel.le étudiant.e
                </div>
                <div class="card-body">
                    <label for="name">Nom</label>
                    <input type="text" name="name" class='form-control'>
                    
                    <label for="email">Courriel</label>
                    <input type="text" name="email" class="form-control">

                    <label for="address">Adresse</label>
                    <input type="text" name="address" class="form-control" >

                    <label for="phone">Numéro de téléphone</label>
                    <input type="text" name="phone" class="form-control">

                    <label for="bday">Date de naissance</label>
                    <input type="date" name="bday" class="form-control">

                    <label for="city">Ville</label>
                    <select id="city" name="city_id" class="form-control">
                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value='<?php echo e($city->id); ?>'><?php echo e($city->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="card-footer text-center">
                    <input type="submit" class="btn btn-success" value="Enregistrer">
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cadriciel23\maisonneuve2195352-2\resources\views/maisonneuve/create.blade.php ENDPATH**/ ?>